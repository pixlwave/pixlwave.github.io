/*{
    "CREDIT": "pixlwave",
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		},
		{
			"NAME": "left",
			"TYPE": "float",
			"DEFAULT": 0.0,
			"MIN": 0.0,
			"MAX": 1.0
		},
		{
			"NAME": "bottom",
			"TYPE": "float",
			"DEFAULT": 0.0,
			"MIN": 0.0,
			"MAX": 1.0
		},
		{
			"NAME": "right",
			"TYPE": "float",
			"DEFAULT": 1.0,
			"MIN": 0.0,
			"MAX": 1.0
		},
		{
			"NAME": "top",
			"TYPE": "float",
			"DEFAULT": 1.0,
			"MIN": 0.0,
			"MAX": 1.0
		}
	]	
}*/

void main()	{
    // calculate the frame and size of the crop
    vec4 frame = vec4(left, bottom, right, top) * vec4(_inputImage_imgSize.xyxy);
    vec2 frameSize = vec2(frame.z - frame.x, frame.w - frame.y);

    // calculate texture coordinate to sample
    vec2 sourceCoord = vec2(vv_FragNormCoord * frameSize + frame.xy);
    
    gl_FragColor = IMG_PIXEL(inputImage, sourceCoord);
}
