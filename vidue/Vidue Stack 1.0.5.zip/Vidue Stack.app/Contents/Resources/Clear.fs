/*{
    "CREDIT": "pixlwave"	
}*/

void main()	{
    vec4 clearColor = vec4(0.0, 0.0, 0.0, 0.0);
    gl_FragColor = clearColor;
}
