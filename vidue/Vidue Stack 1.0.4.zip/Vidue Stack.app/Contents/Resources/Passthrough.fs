/*{
    "CREDIT": "pixlwave",
	"INPUTS": [
		{
			"NAME": "inputImage",
			"TYPE": "image"
		}
	]	
}*/

void main()	{
    gl_FragColor = IMG_THIS_NORM_PIXEL(inputImage);
}
