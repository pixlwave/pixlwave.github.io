/*{
    "CREDIT": "pixlwave"
}*/

void main()	{
    vec4 pixelColor = vec4(0.0, 0.0, 1.0, 1.0);
    
    if ((mod(gl_FragCoord.x, ((RENDERSIZE.x - 2.0) / 8.0)) < 2.0) || (mod(gl_FragCoord.y, ((RENDERSIZE.y - 2.0) / 8.0)) < 2.0))
        pixelColor = vec4(1.0, 0.57647, 0.09804, 1.0);
    gl_FragColor = pixelColor;
}
