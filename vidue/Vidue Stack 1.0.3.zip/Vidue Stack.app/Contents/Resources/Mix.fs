/*{
    "CREDIT": "pixlwave",
	"INPUTS": [
        {
            "NAME": "inputImage",
            "TYPE": "image"
        },
        {
            "NAME": "input2Image",
            "TYPE": "image"
        },
        {
            "NAME": "crossfade",
            "TYPE": "float",
            "DEFAULT": 0.0
        }
	]

}*/

void main()	{
    gl_FragColor = mix(IMG_THIS_NORM_PIXEL(inputImage), IMG_THIS_NORM_PIXEL(input2Image), crossfade);
}
